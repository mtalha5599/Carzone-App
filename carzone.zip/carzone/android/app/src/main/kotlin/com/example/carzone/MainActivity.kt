package com.example.carzone

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
